package sop



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class ContentDetailsController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond ContentDetails.list(params), model:[contentDetailsInstanceCount: ContentDetails.count()]
    }

    def show(ContentDetails contentDetailsInstance) {
        respond contentDetailsInstance
    }

    def create() {
        respond new ContentDetails(params)
    }

    @Transactional
    def save(ContentDetails contentDetailsInstance) {
        if (contentDetailsInstance == null) {
            notFound()
            return
        }

        if (contentDetailsInstance.hasErrors()) {
            respond contentDetailsInstance.errors, view:'create'
            return
        }

        contentDetailsInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'contentDetails.label', default: 'ContentDetails'), contentDetailsInstance.id])
                redirect contentDetailsInstance
            }
            '*' { respond contentDetailsInstance, [status: CREATED] }
        }
    }

    def edit(ContentDetails contentDetailsInstance) {
        respond contentDetailsInstance
    }

    @Transactional
    def update(ContentDetails contentDetailsInstance) {
        if (contentDetailsInstance == null) {
            notFound()
            return
        }

        if (contentDetailsInstance.hasErrors()) {
            respond contentDetailsInstance.errors, view:'edit'
            return
        }

        contentDetailsInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'ContentDetails.label', default: 'ContentDetails'), contentDetailsInstance.id])
                redirect contentDetailsInstance
            }
            '*'{ respond contentDetailsInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(ContentDetails contentDetailsInstance) {

        if (contentDetailsInstance == null) {
            notFound()
            return
        }

        contentDetailsInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'ContentDetails.label', default: 'ContentDetails'), contentDetailsInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'contentDetails.label', default: 'ContentDetails'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
