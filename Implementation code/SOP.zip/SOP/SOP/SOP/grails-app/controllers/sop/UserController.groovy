package sop

import grails.converters.JSON

import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage
import javax.servlet.http.Cookie
import java.text.SimpleDateFormat



import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = false)
class UserController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]



    def signOut() {
        if(String.valueOf(params?.userId).length() == 0 ){
            redirect(uri: '/')

            return

        }

        def ck = request.getCookies();

        for (Cookie cookie : ck) {
            if (cookie.value == params?.userId) {
                cookie.value = false
                cookie.maxAge = 0
                response.addCookie(cookie)

                redirect(uri: '/')

                return


            }

        }
    }

    def signOut1(){
        System.out.print("dd")
        redirect(uri: '/')
        return


    }
        def index(Integer max) {
            params.max = Math.min(max ?: 10, 100)
            respond User.list(params), model: [userInstanceCount: User.count()]
        }

        def show(User userInstance) {
            respond userInstance
        }

        def create() {
            respond new User(params)
        }

        @Transactional
        def save(User userInstance) {
            if (userInstance == null) {
                notFound()
                return
            }

            if (userInstance.hasErrors()) {
                respond userInstance.errors, view: 'create'
                return
            }

            userInstance.save flush: true

            request.withFormat {
                form multipartForm {
                    flash.message = message(code: 'default.created.message', args: [message(code: 'user.label', default: 'User'), userInstance.id])
                    redirect userInstance
                }
                '*' { respond userInstance, [status: CREATED] }
            }
        }

        def edit(User userInstance) {
            respond userInstance
        }

        @Transactional
        def update(User userInstance) {
            if (userInstance == null) {
                notFound()
                return
            }

            if (userInstance.hasErrors()) {
                respond userInstance.errors, view: 'edit'
                return
            }

            userInstance.save flush: true

            request.withFormat {
                form multipartForm {
                    flash.message = message(code: 'default.updated.message', args: [message(code: 'User.label', default: 'User'), userInstance.id])
                    redirect userInstance
                }
                '*' { respond userInstance, [status: OK] }
            }
        }

        @Transactional
        def delete(User userInstance) {

            if (userInstance == null) {
                notFound()
                return
            }

            userInstance.delete flush: true

            request.withFormat {
                form multipartForm {
                    flash.message = message(code: 'default.deleted.message', args: [message(code: 'User.label', default: 'User'), userInstance.id])
                    redirect action: "index", method: "GET"
                }
                '*' { render status: NO_CONTENT }
            }
        }


        def createUser() {
            respond new User(params)


        }

        def signIn() {

        }

        def checkScheduledQuiz() {
            def listOfQuiz = Quiz.list()
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
            String dateOfToday = dateWithFormat()

            def listOfQuiz2 = new ArrayList<>();

            for (Quiz quiz1 : listOfQuiz) {
                if (sdf.parse(String.valueOf(quiz1.quizDate)).compareTo(sdf.parse(dateOfToday)) == 0) {
                    listOfQuiz2.add(quiz1)
                }

            }

            return listOfQuiz2;

        }

        def validateUserCredential() {
            User user = User.findByUserNameAndPassword(params.userName, params.password)


            if (params?.guest == "on") {
                render(view: 'formTemplateForAdmin', model: [id: 0, user: null, contentList: Content.list(), languageList: Language.list()])
                return;


            } else if (user) {

                if (user?.role == "admin") {
                    Cookie ck = new Cookie("userId", "${user?.id}");//deleting value of cookie
                    response.addCookie(ck)
                    def listOfQuiz1 = quizCheck()

                    render(view: 'formTemplateForAdmin', model: [id: {
                        user?.id
                    }, user                                        : user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])

                    return;

                } else if (user?.role == "registered") {
                    Cookie ck = new Cookie("userId", "${user?.id}");//deleting value of cookie
                    response.addCookie(ck)
                    def listOfQuiz2 = checkScheduledQuiz()

                    render(view: 'formTemplateForAdmin', model: [id: {
                        user?.id
                    }, user                                        : user, contentList: Content.list(), languageList: Language.list(), listOfQuiz2: listOfQuiz2])

                    return;

                }

            }








            render(view: 'signIn', model: [message: "Invalid username or password"])


        }

        def addLanguage() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))
            [user: user, languageInstance: new Language(params), contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

    @Transactional
    def saveLanguageInfo(Language languageInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            if (languageInstance == null) {
                notFound()
                return
            }

            if (languageInstance.hasErrors()) {
                respond languageInstance.errors, view: 'create'
                return
            }

            languageInstance.save flush: true
            def languageInstanceList = Language.list()
            render(view: 'listOfLanguage', model: [message: "You have successfully added language information", languageInstanceList: languageInstanceList, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])
        }


        def updateLanguageInfo(Language languageInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            if (languageInstance == null) {
                notFound()
                return
            }

            if (languageInstance.hasErrors()) {
                respond languageInstance.errors, view: 'edit'
                return
            }

            languageInstance.save flush: true
            render(view: 'listOfLanguage', model: [message: "You have successfully updated language information", languageInstanceList: Language.list(), user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])


        }

        def deleteLanguage(Language languageInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))
            if (languageInstance == null) {
                notFound()
                return
            }

            languageInstance.delete flush: true
            render(view: 'listOfLanguage', model: [message: "You have successfully deleted language information", languageInstanceList: Language.list(), user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])
        }


        def listOfLanguage() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))

            def languageInstanceList = Language.list();
            [languageInstanceList: languageInstanceList, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]

        }

        def viewLanguage(Language languageInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [languageInstance: languageInstance, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def editLanguage(Language languageInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [languageInstance: languageInstance, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def addContent() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))
            [user: user, contentInstance: new Content(params), contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]

        }

        @Transactional
        def saveContentInfo(Content contentInstance) {

            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            if (contentInstance == null) {
                notFound()
                return
            }

            if (contentInstance.hasErrors()) {
                respond contentInstance.errors, view: 'create'
                return
            }

            contentInstance.save flush: true
            def contentInstanceList = Content.list()
            render(view: 'listOfContent', model: [message: "You have successfully added content information", contentInstanceList: contentInstanceList, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])

        }


        def listOfContent() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))

            def contentInstanceList = Content.list();
            [contentInstanceList: contentInstanceList, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]

        }

        def viewContent(Content contentInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [contentInstance: contentInstance, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]
        }

        def editContent(Content contentInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [contentInstance: contentInstance, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }


        def updateContentInfo(Content contentInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            if (contentInstance == null) {
                notFound()
                return
            }

            if (contentInstance.hasErrors()) {
                respond contentInstance.errors, view: 'edit'
                return
            }

            contentInstance.save flush: true
            def contentInstanceList = Content.list()
            render(view: 'listOfContent', model: [message: "You have successfully updated content information", contentInstanceList: contentInstanceList, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])


        }


        def deleteContent(Content contentInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            if (contentInstance == null) {
                notFound()
                return
            }

            contentInstance.delete flush: true
            def contentInstanceList = Content.list()
            render(view: 'listOfContent', model: [message: "You have successfully deleted content information", contentInstanceList: contentInstanceList, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])


        }


        def addContentDetails() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))
            [contentDetailsInstance: new ContentDetails(params), user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]

        }

        def saveContentDetailsInfo(ContentDetails contentDetailsInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            if (contentDetailsInstance == null) {
                notFound()
                return
            }

            if (contentDetailsInstance.hasErrors()) {
                respond contentDetailsInstance.errors, view: 'create'
                return
            }
            contentDetailsInstance.validate()
            contentDetailsInstance.clearErrors()
            contentDetailsInstance.language = Language.get(Long.valueOf(params?.language))
            contentDetailsInstance.content = Content.get(Long.valueOf(params?.content))


            contentDetailsInstance.save flush: true
            def contentDetailsList = ContentDetails.list()
            render(view: 'listOfContentDetails', model: [contentDetailsList: contentDetailsList, contentDetailsInstanceCount: contentDetailsList.size(), user: user, message: "You have successfully added content details", contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])


        }

        def listOfContentDetails() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            params.max = 10

            def contentDetailsList
            if (params?.search) {
                contentDetailsList = ContentDetails.createCriteria().list(params) {
                    eq("language", Language.get(Long.valueOf(params?.language)))
                    if (params?.content)
                        eq("content", Content.get(Long.valueOf(params?.content)))

                }
            } else {
                contentDetailsList = ContentDetails.list()
            }
            [contentDetailsList: contentDetailsList, contentDetailsInstanceCount: contentDetailsList.size(), language: params?.language, content: params?.content, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def updateContentDetailsInfo(ContentDetails contentDetailsInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            if (contentDetailsInstance == null) {
                notFound()
                return
            }

            if (contentDetailsInstance.hasErrors()) {
                respond contentDetailsInstance.errors, view: 'create'
                return
            }

            contentDetailsInstance.save flush: true
            def contentDetailsList = ContentDetails.list()

            render(view: 'listOfContentDetails', model: [contentDetailsList: contentDetailsList, contentDetailsInstanceCount: contentDetailsList.size(), user: user, message: "You have successfully updated content details."], contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1)

        }

        def viewContentDetails(ContentDetails contentDetailsInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [user: user, contentDetailsInstance: contentDetailsInstance, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }


        def editContentDetails(ContentDetails contentDetailsInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [user: user, contentDetailsInstance: contentDetailsInstance, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]

        }

        def deleteContentDetails(ContentDetails contentDetailsInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            if (contentDetailsInstance == null) {
                notFound()
                return
            }

            contentDetailsInstance.delete flush: true
            def contentDetailsList = ContentDetails.list()

            render(view: 'listOfContentDetails', model: [contentDetailsList: contentDetailsList, contentDetailsInstanceCount: contentDetailsList.size(), user: user, message: "You have successfully deleted content details.", contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1])
        }

        def showContentDetails() {
            def listOfQuiz1 = quizCheck()
            def contentDetailsList = ContentDetails.createCriteria().list(params) {
                eq("language", Language.get(Long.valueOf(params?.languageId)))
                eq("content", Content.get(Long.valueOf(params?.contentId)))

            }

            if(params?.userId){
                User user = User.get(Long.valueOf(params?.userId))
                [contentDetailsList: contentDetailsList, user: user, contentList: Content.list(), languageList: Language.list(), content: Content.get(Long.valueOf(params?.contentId)), listOfQuiz1: listOfQuiz1]



            }
            else{
                [contentDetailsList: contentDetailsList, user: null, contentList: Content.list(), languageList: Language.list(), content: Content.get(Long.valueOf(params?.contentId)), listOfQuiz1: listOfQuiz1]

            }




        }

        def viewDetailsOfContent(ContentDetails contentDetailsInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [contentDetailsInstance: contentDetailsInstance, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def editProfile() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.id))
            [user: user, userInstance: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def updateUserInfo(User userInstance) {
            def listOfQuiz1 = quizCheck()
            if (userInstance == null) {
                notFound()
                return
            }

            if (userInstance.hasErrors()) {
                respond userInstance.errors, view: 'edit'
                return
            }

            userInstance.save flush: true
            render(view: 'editProfile', model: [user: userInstance, userInstance: userInstance, contentList: Content.list(), languageList: Language.list(), message: "Successfully updated your information.", listOfQuiz1: listOfQuiz1]);
        }

        def registrationForm() {

            [userInstance: new User(params)]


        }

        def saveRegisteredInfo(User userInstance) {
            def listOfQuiz1 = quizCheck()
            if (userInstance == null) {
                notFound()
                return
            }
            userInstance.role = "registered"
            userInstance.validate()
            userInstance.clearErrors()



            if (userInstance.hasErrors()) {
                respond userInstance.errors, view: 'create'
                return
            }

            userInstance.save flush: true
            render(view: 'registrationForm', model: [message: "You are successfully registered ", listOfQuiz1: listOfQuiz1])


        }

        def checkDuplicacyOfUserName() {
            LinkedHashMap postInfo = new LinkedHashMap()
            String output

            User user = User.findByUserName(params?.input)
            if (user) {
                postInfo.put('availAble', true)
            } else postInfo.put('availAble', false)

            output = postInfo as JSON
            render output
            return
        }

        def addQuestionAndAnswerForm() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Language language = Language.get(Long.valueOf(params?.languageId))

            [questionAndAnswerForQuizInatance: new QuestionAndAnswerForQuiz(params), user: user, language: language, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def saveQuestionAndAnswerInfo(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
            User user = User.get(Long.valueOf(params?.userId))
            Language language = Language.get(Long.valueOf(params?.languageId))

            if (questionAndAnswerForQuizInstance == null) {
                notFound()
                return
            }

            questionAndAnswerForQuizInstance.language = language
            questionAndAnswerForQuizInstance.quizIndicator = "anytimeQuiz"
            questionAndAnswerForQuizInstance.validate()
            questionAndAnswerForQuizInstance.clearErrors()


            if (questionAndAnswerForQuizInstance.hasErrors()) {
                respond questionAndAnswerForQuizInstance.errors, view: 'create'
                return
            }

            questionAndAnswerForQuizInstance.save flush: true
            def listOfQuiz1 = quizCheck()


            render(view: 'addQuestionAndAnswerForm', model: [user: user, language: language, contentList: Content.list(), languageList: Language.list(), message: "Successfully added Question and Answer", listOfQuiz1: listOfQuiz1])
        }


        def listOfQuestionAndAnswerForAnytimeQuiz() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Language language = Language.get(Long.valueOf(params?.languageId))
            def listOfQuestionAndAnswerForQuiz = QuestionAndAnswerForQuiz.createCriteria().list(params) {
                eq("language", Language.get(Long.valueOf(params?.languageId)))
                eq("quizIndicator", "anytimeQuiz")
            }

            [user: user, language: language, listOfQuestionAndAnswerForQuiz: listOfQuestionAndAnswerForQuiz, language: language, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }


        def editQuestion(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            [questionAndAnswerForQuizInstance: questionAndAnswerForQuizInstance, user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]

        }

        def updateQuestionAndAnswerInfo(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))

            if (questionAndAnswerForQuizInstance == null) {
                notFound()
                return
            }
            questionAndAnswerForQuizInstance.validate()
            questionAndAnswerForQuizInstance.clearErrors()

            if (questionAndAnswerForQuizInstance.hasErrors()) {
                respond questionAndAnswerForQuizInstance.errors, view: 'edit'
                return
            }

            questionAndAnswerForQuizInstance.save flush: true
            def listOfQuestionAndAnswerForQuiz = QuestionAndAnswerForQuiz.createCriteria().list(params) {
                eq("language", Language.get(Long.valueOf(params?.languageId)))
                eq("quizIndicator", "anytimeQuiz")
            }

            render(view: 'listOfQuestionAndAnswerForAnytimeQuiz', model: [user: user, language: Language.get(Long.valueOf(params?.languageId)), listOfQuestionAndAnswerForQuiz: listOfQuestionAndAnswerForQuiz, contentList: Content.list(), languageList: Language.list(), message: "Successfully updated question.", listOfQuiz1: listOfQuiz1])

//        [user : user, language : Language.get(Long.valueOf(params?.languageId)), listOfQuestionAndAnswerForQuiz : listOfQuestionAndAnswerForQuiz,  contentList : Content.list(), languageList: Language.list(), message: "Successfully updated question."]


        }

        def deleteQuestion(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Language language = Language.get(questionAndAnswerForQuizInstance?.language?.id)



            if (questionAndAnswerForQuizInstance == null) {
                notFound()
                return
            }

            questionAndAnswerForQuizInstance.delete flush: true
            def listOfQuestionAndAnswerForQuiz = QuestionAndAnswerForQuiz.createCriteria().list(params) {
                eq("language", language)
                eq("quizIndicator", "anytimeQuiz")
            }
            render(view: 'listOfQuestionAndAnswerForAnytimeQuiz', model: [user: user, language: language, listOfQuestionAndAnswerForQuiz: listOfQuestionAndAnswerForQuiz, contentList: Content.list(), languageList: Language.list(), message: "Successfully deleted question.", listOfQuiz1: listOfQuiz1])
        }

        def anyTimeQuiz() {
            def listOfQuiz1 = quizCheck()

            User user = User.get(Long.valueOf(params?.userId))
            Language language = Language.get(Long.valueOf(params?.languageId))
            def listOfQuestionAndAnswerForQuiz = QuestionAndAnswerForQuiz.createCriteria().list(params) {
                eq("language", language)
                eq("quizIndicator", "anytimeQuiz")
            }

            [user: user, language: language, listOfQuestionAndAnswerForQuiz: listOfQuestionAndAnswerForQuiz, numberOfQuestion: listOfQuestionAndAnswerForQuiz.size(), contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def checkScriptForAll() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId[0]))
            Language language = Language.get(Long.valueOf(params?.languageId[0]))
            int totalMark = 0;
            def listOfQuestionAndAnswerForQuiz = QuestionAndAnswerForQuiz.createCriteria().list(params) {
                eq("language", language)
                eq("quizIndicator", "anytimeQuiz")
            }

            for (int i = 1; i <= Long.valueOf(params.numberOfQuestion[0]); i++) {
                String q = "question" + String.valueOf(i)
                String a = "answer" + String.valueOf(i)
                if (params["question" + i] == params["answer" + i]) {
                    totalMark = totalMark + 1;
                }

            }

            String message = "Your score : " + totalMark ;

            render(view: 'anyTimeQuiz', model: [user: user, language: language, listOfQuestionAndAnswerForQuiz: listOfQuestionAndAnswerForQuiz, numberOfQuestion: listOfQuestionAndAnswerForQuiz.size(), contentList: Content.list(), languageList: Language.list(), message: message, listOfQuiz1: listOfQuiz1])


        }


        def addQuiz() {
            def listOfQuiz1 = quizCheck()

            User user = User.get(Long.valueOf(params?.userId))
            [user: user, quizInstance: new Quiz(params), contentList: Content.list(), languageList: Language.list(), listOfQuiz1: listOfQuiz1]


        }

        def saveQuizInfo(Quiz quizInstance) {
            def listOfQuiz1 = quizCheck()

            if (quizInstance == null) {
                notFound()
                return
            }

            if (quizInstance.hasErrors()) {
                respond quizInstance.errors, view: 'create'
                return
            }

            quizInstance.save flush: true
            User user = User.get(Long.valueOf(params?.userId))

            def listOfRegisteredPerson = User.findAllByRole('registered')

            final String from = "schoolofprogramming2@gmail.com";

            String host = "smtp.gmail.com";

            for (User user1 : listOfRegisteredPerson) {
                Properties properties = System.getProperties();
                properties.put("mail.smtp.starttls.enable", true);
                properties.put("mail.smtp.host", host);
                properties.put("mail.smtp.user", from);
                properties.put("mail.smtp.password", "Rockon555");
                properties.put("mail.smtp.socketFactory.port", "465");
                properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                properties.put("mail.smtp.port", 587);
                properties.put("mail.smtp.auth", "true");

                Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(from, "Rockon555");
                    }
                });

                try {

                    MimeMessage message = new MimeMessage(session);
                    String textMessage = "Upcoming Quiz : " + quizInstance?.quizName + "  and Date : " + quizInstance.quizDate

                    message.setFrom(new InternetAddress(from));
                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(user1?.emailAddress));
                    message.setSubject("Quiz");
                    message.setText(textMessage);


                    Transport.send(message);
                    System.out.println("Sent message successfully....");

                } catch (MessagingException mex) {
                    mex.printStackTrace();
                }

            }


            render(view: 'addQuiz', model: [user: user, contentList: Content.list(), languageList: Language.list(), message: "You have successfully added quiz and notified all the registered users", listOfQuiz1: listOfQuiz1])
        }

        String dateWithFormat() {
            Date today = new Date();
            String day = String.valueOf(new Date()).substring(8, 10)
            String month = String.valueOf(new Date()).substring(4, 7);
            String year = String.valueOf(new Date()).substring(24)
            if (month.equals("Jan")) {
                month = "01";
            } else if (month.equals("Feb")) {
                month = "02"

            } else if (month.equals("Mar")) {
                month = "03"

            } else if (month.equals("Apr")) {
                month = "04"

            } else if (month.equals("May")) {
                month = "05"

            } else if (month.equals("Jun")) {
                month = "06"

            } else if (month.equals("Jul")) {
                month = "07"

            } else if (month.equals("Aug")) {
                month = "08"

            } else if (month.equals("Sep")) {
                month = "09"

            } else if (month.equals("Oct")) {
                month = "10"

            } else if (month.equals("Nov")) {
                month = "11"

            } else if (month.equals("Dec")) {
                month = "12"

            }

            String xx = year + "-" + month + "-" + day
            return xx;

        }

    @Transactional
        def quizCheck() {

            def listOfQuiz = Quiz.list()
//        def listOfQuiz1 = Quiz.findAllByQuizDateGreaterThanEquals(new Date())
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
            String dateOfToday = dateWithFormat()

            def listOfQuiz1 = new ArrayList<>();

            for (Quiz quiz1 : listOfQuiz) {
                if (sdf.parse(String.valueOf(quiz1.quizDate)).compareTo(sdf.parse(dateOfToday)) >= 0) {
                    listOfQuiz1.add(quiz1)
                }

            }
            return listOfQuiz1
        }


        def listOfQuiz() {
            User user = User.get(Long.valueOf(params?.userId))

            def listOfQuiz = Quiz.list()
//        def listOfQuiz1 = Quiz.findAllByQuizDateGreaterThanEquals(new Date())
            def listOfQuiz1 = quizCheck()
            [user: user, contentList: Content.list(), languageList: Language.list(), listOfQuiz: listOfQuiz, listOfQuiz1: listOfQuiz1]


        }

        def viewQuiz(Quiz quizInstance) {
            def listOfQuiz1 = quizCheck()

            User user = User.get(Long.valueOf(params?.userId))
            [user: user, contentList: Content.list(), languageList: Language.list(), quizInstance: quizInstance, listOfQuiz1: listOfQuiz1]

        }

        def addQuestionAndAnswerFormForSheduleQuiz() {
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            [questionAnswerForScheduledQuizInstance: new QuestionAnswerForScheduledQuiz(params), quiz: quiz, user: user, listOfQuiz1: listOfQuiz1, contentList: Content.list(), languageList: Language.list()]


        }

        def saveQuestionAndAnswerInfoForScheduledQuiz(QuestionAnswerForScheduledQuiz questionAnswerForScheduledQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))


            if (questionAnswerForScheduledQuizInstance == null) {
                notFound()
                return
            }

            questionAnswerForScheduledQuizInstance.quiz = quiz
            questionAnswerForScheduledQuizInstance.validate()
            questionAnswerForScheduledQuizInstance.clearErrors()


            if (questionAnswerForScheduledQuizInstance.hasErrors()) {
                respond questionAnswerForScheduledQuizInstance.errors, view: 'create'
                return
            }

            questionAnswerForScheduledQuizInstance.save flush: true

            render(view: 'addQuestionAndAnswerFormForSheduleQuiz', model: [user: user, listOfQuiz1: listOfQuiz1, quiz: quiz, message: "Successfully added question", contentList: Content.list(), languageList: Language.list()])

        }


        def listOfQuestionAndAnswerForSheduleQuiz() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))

            def questionList = QuestionAnswerForScheduledQuiz.createCriteria().list(params) {
                eq("quiz", Quiz.get(Long.valueOf(params?.quizInstanceId)))
            }
            [user: user, quiz: quiz, listOfQuiz1: listOfQuiz1, questionList: questionList, contentList: Content.list(), languageList: Language.list()]

        }


        def editQuestionForSheduledQuiz(QuestionAnswerForScheduledQuiz questionAnswerForScheduledQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))

            [listOfQuiz1: listOfQuiz1, user: user, quiz: quiz, questionAnswerForScheduledQuizInstance: questionAnswerForScheduledQuizInstance]

        }

        def deleteQuestionForSheduledQuiz(QuestionAnswerForScheduledQuiz questionAnswerForScheduledQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))
            if (questionAnswerForScheduledQuizInstance == null) {
                notFound()
                return
            }

            questionAnswerForScheduledQuizInstance.delete flush: true
            def questionList = QuestionAnswerForScheduledQuiz.createCriteria().list(params) {
                eq("quiz", Quiz.get(Long.valueOf(params?.quizInstanceId)))

            }

            render(view: 'listOfQuestionAndAnswerForSheduleQuiz', model: [user: user, quiz: quiz, listOfQuiz1: listOfQuiz1, questionList: questionList, contentList: Content.list(), languageList: Language.list(), message: "Successfully deleted question"])


        }

        def updateQuestionAndAnswerInfoForScheduledQuiz(QuestionAnswerForScheduledQuiz questionAnswerForScheduledQuizInstance) {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))

            if (questionAnswerForScheduledQuizInstance == null) {
                notFound()
                return
            }
            questionAnswerForScheduledQuizInstance.validate()
            questionAnswerForScheduledQuizInstance.clearErrors()
            if (questionAnswerForScheduledQuizInstance.hasErrors()) {
                respond questionAnswerForScheduledQuizInstance.errors, view: 'edit'
                return
            }

            questionAnswerForScheduledQuizInstance.save flush: true

            render(view: 'addQuestionAndAnswerFormForSheduleQuiz', model: [user: user, listOfQuiz1: listOfQuiz1, quiz: quiz, message: "Successfully updated question", contentList: Content.list(), languageList: Language.list()])


        }

        def appearAtScheduledQuiz() {
            def listOfQuiz1 = quizCheck()
            User user = User.get(Long.valueOf(params?.userId))
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))
            def listOfQuiz2 = checkScheduledQuiz()

            def questionList = QuestionAnswerForScheduledQuiz.findAllByQuiz(quiz)
            [questionList: questionList, numberOfQuestion: questionList.size(), contentList: Content.list(), languageList: Language.list(), user: user, listOfQuiz1: listOfQuiz1, listOfQuiz2: listOfQuiz2, quiz: quiz]


        }

        def checkScriptForAllForSche() {
            def listOfQuiz1 = quizCheck()
            def listOfQuiz2 = checkScheduledQuiz()
            Quiz quiz = Quiz.get(Long.valueOf(params?.quizInstanceId))


            User user = User.get(Long.valueOf(params?.userId))
            int totalMark = 0;
            def questionList = QuestionAnswerForScheduledQuiz.findAllByQuiz(Quiz.get(Long.valueOf(params?.quizInstanceId)))

            for (int i = 1; i <= Long.valueOf(params.numberOfQuestion[0]); i++) {
                String q = "question" + String.valueOf(i)
                String a = "answer" + String.valueOf(i)
                if (params["question" + i] == params["answer" + i]) {
                    totalMark = totalMark + 1;
                }

            }

//        String message = "You have got : "+totalMark;


            final String from = "schoolofprogramming2@gmail.com";

            String host = "smtp.gmail.com";

            Properties properties = System.getProperties();
            properties.put("mail.smtp.starttls.enable", true);
            properties.put("mail.smtp.host", host);
            properties.put("mail.smtp.user", from);
            properties.put("mail.smtp.password", "Rockon555");
            properties.put("mail.smtp.socketFactory.port", "465");
            properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            properties.put("mail.smtp.port", 587);
            properties.put("mail.smtp.auth", "true");

            Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(from, "Rockon555");
                }
            });

            try {

                MimeMessage message = new MimeMessage(session);
                String textMessage = "You have obtained : " + totalMark + "  in quiz : " + quiz?.quizName

                message.setFrom(new InternetAddress(from));
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(user?.emailAddress));
                message.setSubject("Quiz Result");
                message.setText(textMessage);


                Transport.send(message);
                System.out.println("Sent message successfully....");

            } catch (MessagingException mex) {
                mex.printStackTrace();
            }


            render(view: 'appearAtScheduledQuiz', model: [questionList: questionList, numberOfQuestion: questionList.size(), contentList: Content.list(), languageList: Language.list(), user: user, listOfQuiz1: listOfQuiz1, listOfQuiz2: listOfQuiz2, quiz: quiz, message: "Your obtained marks is sent to your email.Please check it..."])


        }


    def about(){

    }




        protected void notFound() {
            request.withFormat {
                form multipartForm {
                    flash.message = message(code: 'default.not.found.message', args: [message(code: 'user.label', default: 'User'), params.id])
                    redirect action: "index", method: "GET"
                }
                '*' { render status: NOT_FOUND }
            }
        }
    }
