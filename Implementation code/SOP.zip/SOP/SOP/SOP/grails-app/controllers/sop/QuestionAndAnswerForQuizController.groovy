package sop



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = false)
class QuestionAndAnswerForQuizController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond QuestionAndAnswerForQuiz.list(params), model:[questionAndAnswerForQuizInstanceCount: QuestionAndAnswerForQuiz.count()]
    }

    def show(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
        respond questionAndAnswerForQuizInstance
    }

    def create() {
        respond new QuestionAndAnswerForQuiz(params)
    }

    @Transactional
    def save(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
        if (questionAndAnswerForQuizInstance == null) {
            notFound()
            return
        }

        if (questionAndAnswerForQuizInstance.hasErrors()) {
            respond questionAndAnswerForQuizInstance.errors, view:'create'
            return
        }

        questionAndAnswerForQuizInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'questionAndAnswerForQuiz.label', default: 'QuestionAndAnswerForQuiz'), questionAndAnswerForQuizInstance.id])
                redirect questionAndAnswerForQuizInstance
            }
            '*' { respond questionAndAnswerForQuizInstance, [status: CREATED] }
        }
    }

    def edit(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
        respond questionAndAnswerForQuizInstance
    }

    @Transactional
    def update(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {
        if (questionAndAnswerForQuizInstance == null) {
            notFound()
            return
        }

        if (questionAndAnswerForQuizInstance.hasErrors()) {
            respond questionAndAnswerForQuizInstance.errors, view:'edit'
            return
        }

        questionAndAnswerForQuizInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'QuestionAndAnswerForQuiz.label', default: 'QuestionAndAnswerForQuiz'), questionAndAnswerForQuizInstance.id])
                redirect questionAndAnswerForQuizInstance
            }
            '*'{ respond questionAndAnswerForQuizInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(QuestionAndAnswerForQuiz questionAndAnswerForQuizInstance) {

        if (questionAndAnswerForQuizInstance == null) {
            notFound()
            return
        }

        questionAndAnswerForQuizInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'QuestionAndAnswerForQuiz.label', default: 'QuestionAndAnswerForQuiz'), questionAndAnswerForQuizInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'questionAndAnswerForQuiz.label', default: 'QuestionAndAnswerForQuiz'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
