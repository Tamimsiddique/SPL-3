package sop

class ContentDetails {
    Language language
    Content content
    String contentDetails

    static constraints = {
        language nullable: false
        content nullable: false
        contentDetails nullable: false
    }
}
