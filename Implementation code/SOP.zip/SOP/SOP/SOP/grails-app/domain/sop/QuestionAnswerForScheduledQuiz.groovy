package sop

class QuestionAnswerForScheduledQuiz {
    String question, option1, option2, option3, option4, answer
    Quiz quiz

    static constraints = {
        question nullable: false
        option1 nullable: false
        option2 nullable: false
        answer nullable: false
        quiz nullable: false
        option3 nullable: true
        option4 nullable: true
    }
}
