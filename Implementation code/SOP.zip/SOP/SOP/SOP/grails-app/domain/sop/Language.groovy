package sop

class Language {
    String languageName, languageDescription

    static constraints = {
        languageName nullable: false
        languageDescription nullable: true
    }
}
