package sop

class Content {
    String contentName, contentDescription

    static constraints = {
        contentName nullable: false
        contentDescription nullable: true

    }
}
