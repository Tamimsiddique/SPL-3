package sop

class QuestionAndAnswerForQuiz {
    String question, option1, option2, option3, option4, answer, quizIndicator
    Language language

    static constraints = {
        question nullable: false
        option1 nullable: false
        option2 nullable: false
        answer nullable: false
        quizIndicator nullable: false
        language nullable: false
        option3 nullable: true
        option4 nullable: true
    }
}
