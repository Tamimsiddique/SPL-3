package sop

class User {
    String userName, password, role, firstName, lastName, emailAddress


    static constraints = {
        userName nullable:false
        password nullable:false
        role nullable:false
        firstName nullable:true
        lastName nullable:true
        emailAddress nullable:true
    }
}
