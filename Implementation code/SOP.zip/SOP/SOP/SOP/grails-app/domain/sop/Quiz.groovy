package sop

class Quiz {
    String quizName
    Date quizDate

    static constraints = {
        quizName nullable: false
        quizDate nullable: false
    }
}
